#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Renderer for the "Upcoming Distributions" panel.

Grey bar  = historical dividend range (13m for A/B/C/D, 52w for Weekly) -> columns HistLow/HistHigh
Blue dot  = this run's estimate                                  -> column Est. Dividend ($)
"""

import argparse, math
import pandas as pd
import matplotlib.pyplot as plt

GROUP_ORDER = ["A","B","C","D","Weekly"]

def money(v):
    try:
        return f"${float(v):,.2f}"
    except Exception:
        return ""

def load_table(path: str) -> pd.DataFrame:
    if path.lower().endswith(".xlsx"):
        df = pd.read_excel(path)
    else:
        df = pd.read_csv(path)
    # Derive numeric fields if only formatted versions exist
    if "Est. Dividend ($)" not in df.columns and "Est. Dividend" in df.columns:
        df["Est. Dividend ($)"] = (
            df["Est. Dividend"].astype(str).str.replace("$","",regex=False).str.replace(",","",regex=False)
            .apply(lambda x: float(x) if x.replace(".","",1).isdigit() else float("nan"))
        )
    for c in ["HistLow","HistHigh","Price ($)","IV30"]:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")
    df["Group"] = pd.Categorical(df["Group"], categories=GROUP_ORDER, ordered=True)
    df = df.sort_values(["Group","Ex-Date","fund"], kind="mergesort")
    return df

def draw(df: pd.DataFrame, out: str):
    # Layout
    counts = {g: int((df["Group"]==g).sum()) for g in GROUP_ORDER}
    n_rows = sum(counts.values())
    row_h, header_h = 0.50, 0.70
    top_m, bot_m = 0.6, 0.6
    fig_h = top_m + bot_m + n_rows*row_h + sum(1 for g in GROUP_ORDER if counts[g]>0)*header_h
    fig_w = 18

    fig = plt.figure(figsize=(fig_w, fig_h))
    ax = plt.gca()
    ax.set_xlim(0, 1)
    ax.set_ylim(0, fig_h)
    ax.axis('off')

    # Columns (normalized)
    x = {
        "Fund": 0.03,
        "Underlying": 0.15,
        "Price": 0.32,
        "IV": 0.40,
        "ExDate": 0.47,
        "EstDiv": 0.56,
        "FwdYield": 0.66,
        "BarL": 0.73,
        "BarR": 0.98,
    }

    # Title
    y = fig_h - 0.3
    ax.text(0.03, y, "Upcoming Distributions", fontsize=18, fontweight="bold", va="top")
    ax.text(0.03, y-0.35, "Grey bar: historical range (13m / 52w). Dot: this run’s estimate.", fontsize=10, va="top")
    y -= 0.9

    # Headers
    ax.text(x["Fund"], y, "Fund", fontsize=11, fontweight='bold')
    ax.text(x["Underlying"], y, "Parent Fund", fontsize=11, fontweight='bold')
    ax.text(x["Price"], y, "Price", fontsize=11, fontweight='bold')
    ax.text(x["IV"], y, "IV (30d)", fontsize=11, fontweight='bold')
    ax.text(x["ExDate"], y, "Ex-Date", fontsize=11, fontweight='bold')
    ax.text(x["EstDiv"], y, "Est. Dividend", fontsize=11, fontweight='bold')
    ax.text(x["FwdYield"], y, "Fwd Yield (Ann.)", fontsize=11, fontweight='bold')
    ax.text((x["BarL"]+x["BarR"])/2, y, "Div range (13m/52w)", fontsize=11, fontweight='bold', ha='center')
    y -= 0.3

    def draw_row(r, yrow):
        ax.text(x["Fund"], yrow, str(r.get("fund","")), fontsize=10, va='center', fontweight='bold')
        ax.text(x["Underlying"], yrow, str(r.get("Underlying","") or "—"), fontsize=10, va='center')
        # price
        px = r.get("Price ($)")
        ax.text(x["Price"], yrow, money(px) if isinstance(px,(float,int)) else str(r.get("Price","")), fontsize=10, va='center')
        # IV
        iv = r.get("IV30")
        ax.text(x["IV"], yrow, f"{iv*100:.0f}%" if isinstance(iv,(float,int)) else str(r.get("IV (30d)","")), fontsize=10, va='center')
        # ex-date
        ax.text(x["ExDate"], yrow, str(r.get("Ex-Date","")), fontsize=10, va='center')
        # est dividend
        est = r.get("Est. Dividend ($)")
        ax.text(x["EstDiv"], yrow, money(est) if isinstance(est,(float,int)) else str(r.get("Est. Dividend","")), fontsize=10, va='center')
        # fwd yield
        ax.text(x["FwdYield"], yrow, str(r.get("Fwd Yield (Ann.)","")), fontsize=10, va='center')

        # Grey bar (HistLow→HistHigh) + blue dot (estimate)
        L, R = x["BarL"], x["BarR"]
        lo, hi = r.get("HistLow"), r.get("HistHigh")
        if isinstance(lo,(float,int)) and isinstance(hi,(float,int)) and hi >= lo and (R-L)>0:
            ax.hlines(yrow, L, R, linewidth=6, color="0.7")  # grey bar
            estv = est if isinstance(est,(float,int)) else None
            if estv is not None and hi > lo:
                pos = L + (estv - lo) / (hi - lo) * (R - L)
                pos = max(L, min(R, pos))
                ax.plot([pos], [yrow], marker="o", markersize=6, color="#1f77b4")  # blue dot
            # edge labels
            ax.text(L, yrow-0.17, money(lo), fontsize=9, va='top')
            ax.text(R, yrow-0.17, money(hi), fontsize=9, va='top', ha='right')
        else:
            ax.plot([(L+R)/2], [yrow], marker="o", markersize=6, color="#1f77b4")

    # Groups
    for g in GROUP_ORDER:
        sub = df[df["Group"]==g]
        if sub.empty: continue
        y -= 0.15
        ax.text(0.03, y, f"GROUP {g}", fontsize=13, fontweight='bold', va='top')
        y -= 0.30
        for _, r in sub.iterrows():
            draw_row(r, y); y -= 0.50
        y -= 0.25

    plt.savefig(out, dpi=200, bbox_inches="tight")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    ap.add_argument("--output", default="upcoming_distributions.png")
    args = ap.parse_args()
    df = load_table(args.input)
    draw(df, args.output)
    print(f"Saved → {args.output}")

if __name__ == "__main__":
    main()
