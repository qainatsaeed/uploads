#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
YieldTrack Pro — historical payout × momentum (calibrated) + IV fallback
- Ex-date cadence generated perpetually from 2025 anchors (no scraping)
- Historical payout × momentum with vol-aware beta and MAD filtering
- Multiplicative calibration (EWMA of errors)
- IV(30d) interpolation or realized-vol proxy when options chain is thin
- Floors: Weekly >= $0; A/B/C/D >= 1% annualized of price (NAV proxy) per period
- Tighter confidence band: **fixed ±10% around calibrated midpoint**
- Historical range (grey bar on chart): **A/B/C/D = last 13 payouts; Weekly = last 52 payouts**
- Yahoo REST endpoints only; 'requests-cache' for rate friendliness
"""

from __future__ import annotations

import argparse, math, random, time, logging
from datetime import date, datetime, timedelta, timezone
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
import requests
import requests_cache

# ---------------- Configuration ----------------
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124 Safari/537.36"
HEADERS = {"User-Agent": UA, "Accept": "application/json, text/plain, */*", "Accept-Language": "en-US,en;q=0.9"}

CACHE_EXPIRE_SEC = 1800  # 30 min cache for Yahoo calls
RATE_LIMIT_SEC, JITTER = 0.35, 0.20

# Frequency used for annualized forward yield
FREQ_BY_GROUP = {"Weekly": 52, "A": 13, "B": 13, "C": 13, "D": 13}

# Range band (fixed around midpoint)
RANGE_PCT_DEFAULT = 0.10  # ±10%

# Client floor rules
MIN_ANN_YIELD_NON_WEEKLY = 0.01  # 1% annualized (price as NAV proxy)

# Calibration
CAL_FACTOR_CLAMP   = (0.60, 1.40)
CAL_ALPHA_MONTHLY  = 0.35
CAL_ALPHA_WEEKLY   = 0.50
CAL_DEFAULT_ERR_EWMA = 0.10
CAL_PATH_DEFAULT   = "ytp_calibration.csv"

# Optimizer
TRAIN_WINDOW_DAYS = 183
OPT_TTL_DAYS      = 7
GRID_MONTHLY = {
    "K":     [3, 4],
    "w":     [0.60, 0.80],
    "L":     [20, 30, 40],
    "beta":  [0.6, 0.8, 1.0],
    "clamp": [0.10, 0.15, 0.20],
}
GRID_WEEKLY = {
    "K":     [6, 8],
    "w":     [0.60, 0.80],
    "L":     [10, 20, 30],
    "beta":  [0.5, 0.7, 0.9],
    "clamp": [0.08, 0.12, 0.16],
}
MIN_TRAIN_EVENTS_MONTHLY = 3
MIN_TRAIN_EVENTS_WEEKLY  = 8

# Vol-aware momentum scaling
RV_REF          = 0.60
RV_MIN_SCALE    = 0.65
RV_MAX_SCALE    = 1.10

# Official roster (pairs cleaned; WNTR→MSTR; PYPY only in B)
FALLBACK_GROUPS = {
    "Weekly": ["CHPY","GPTY","LFGY","QDTY","RDTY","SDTY","ULTY","YMAG","YMAX"],
    "A": ["BRKC","CRSH","FEAT","FIVY","GOOY","OARK","RBLY","SNOY","TSLY","TSMY","XOMO","YBIT"],
    "B": ["BABO","DIPS","FBY","GDXY","JPMO","MARO","MRNY","NVDY","PLTY","PYPY"],
    "C": ["ABNY","AMDY","CONY","CVNY","DRAY","FIAT","HOOY","MSFO","NFLY"],
    "D": ["AIYY","AMZY","APLY","DISO","MSTY","SMCY","WNTR","XYZY","YQQQ"],
}
GROUP_OF = {s: g for g, arr in FALLBACK_GROUPS.items() for s in arr}
WHITELIST = set(GROUP_OF.keys())

UNDERLYING: Dict[str, Optional[str]] = {
    # Group A
    "TSLY":"TSLA","CRSH":"TSLA","GOOY":"GOOGL","OARK":"ARKK","RBLY":"RBLX","SNOY":"SNOW",
    "TSMY":"TSM","XOMO":"XOM","BRKC":"BRK-B","YBIT":"BITO","FEAT":None,"FIVY":None,
    # Group B
    "NVDY":"NVDA","DIPS":"NVDA","PLTY":"PLTR","FBY":"META","MRNY":"MRNA","PYPY":"PYPL","MARO":"MARA","JPMO":"JPM","GDXY":"GDX","BABO":"BABA",
    # Group C
    "AMDY":"AMD","CONY":"COIN","CVNY":"CVNA","HOOY":"HOOD","MSFO":"MSFT","NFLY":"NFLX","ABNY":"ABNB","DRAY":"DKNG","FIAT":"COIN",
    # Group D
    "AMZY":"AMZN","APLY":"AAPL","DISO":"DIS","MSTY":"MSTR","SMCY":"SMCI","AIYY":"AI","YQQQ":"QQQ","WNTR":"MSTR","XYZY":"QQQ",
    # Weekly baskets
    "YMAX":None,"YMAG":None,"ULTY":None,"SDTY":None,"RDTY":None,"QDTY":None,"LFGY":None,"GPTY":None,"CHPY":None,
}

# Cadence anchors (first known ex-dates in 2025); then +28d perpetually
ANCHOR_EX = {
    "A": date(2025, 1, 23),
    "B": date(2025, 1, 3),
    "C": date(2025, 1, 9),
    "D": date(2025, 1, 16),
    "Weekly": date(2025, 1, 3),  # weekly cadence from here (every 7d)
}

# ---------------- Utilities ----------------
def _sleep():
    time.sleep(max(0.0, RATE_LIMIT_SEC + random.uniform(-JITTER, JITTER)))

def normalize_ticker(s: str) -> str:
    if not s: return ""
    return (s.replace("\u2013","-").replace("\u2014","-")
             .replace("\u2212","-").replace("\u00A0"," ").strip().upper())

def fmt_asof(ts: Optional[int]) -> str:
    if ts is None: return ""
    try:
        return datetime.fromtimestamp(int(ts), tz=timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    except Exception:
        return ""

# ---------------- Yahoo endpoints ----------------
def yahoo_quote_batch_prices(session, symbols: List[str]):
    price_map = {s: None for s in symbols}; source_map = {s:"" for s in symbols}; asof_map = {s: None for s in symbols}
    for i in range(0, len(symbols), 40):
        chunk = symbols[i:i+40]
        url = "https://query1.finance.yahoo.com/v7/finance/quote"
        try:
            j = session.get(url, headers=HEADERS, params={"symbols": ",".join(chunk)}, timeout=20).json()
            for q in j.get("quoteResponse", {}).get("result", []):
                sym = normalize_ticker(q.get("symbol",""))
                if sym not in price_map: continue
                def num(x):
                    try: return float(x)
                    except Exception: return None
                rmp = num(q.get("regularMarketPrice")); rmt = q.get("regularMarketTime")
                if rmp is not None: price_map[sym]=rmp; source_map[sym]="regularMarketPrice"; asof_map[sym]=rmt; continue
                pmp = num(q.get("postMarketPrice")); pmt = q.get("postMarketTime")
                if pmp is not None: price_map[sym]=pmp; source_map[sym]="postMarketPrice"; asof_map[sym]=pmt or rmt; continue
                prev = num(q.get("regularMarketPreviousClose"))
                if prev is not None: price_map[sym]=prev; source_map[sym]="previousClose"; asof_map[sym]=rmt; continue
                bid = num(q.get("bid")); ask = num(q.get("ask"))
                if bid and ask and bid>0 and ask>0:
                    price_map[sym]=(bid+ask)/2; source_map[sym]="bid/ask_mid"; asof_map[sym]=rmt
            _sleep()
        except Exception:
            _sleep()
    return price_map, source_map, asof_map

def yahoo_chart_hist(session, symbol, rng="12mo", interval="1d"):
    url = f"https://query1.finance.yahoo.com/v8/finance/chart/{symbol}"
    try:
        j = session.get(url, headers=HEADERS, params={"range": rng, "interval": interval}, timeout=20).json()
        res = j.get("chart", {}).get("result", [])
        if not res: return [], []
        ts = res[0].get("timestamp", []) or []
        q  = res[0].get("indicators", {}).get("quote", [{}])[0]
        closes = q.get("close", []) if q else []
        return ts, closes
    except Exception:
        return [], []

def yahoo_chart_hist_adj(session, symbol, rng="1y", interval="1d"):
    url = f"https://query1.finance.yahoo.com/v8/finance/chart/{symbol}"
    try:
        j = session.get(url, headers=HEADERS, params={"range": rng, "interval": interval}, timeout=20).json()
        res = j.get("chart", {}).get("result", [])
        if not res: return [], []
        ts = res[0].get("timestamp", []) or []
        adj = (res[0].get("indicators", {}) or {}).get("adjclose", [{}])[0].get("adjclose", [])
        return ts, adj if adj else []
    except Exception:
        return [], []

def yahoo_chart_with_divs(session, symbol, rng="18mo", interval="1d"):
    url = f"https://query1.finance.yahoo.com/v8/finance/chart/{symbol}"
    try:
        j = session.get(url, headers=HEADERS,
                        params={"range": rng, "interval": interval, "events":"div"},
                        timeout=20).json()
        res = j.get("chart", {}).get("result", [])
        if not res: return [], [], []
        ts = res[0].get("timestamp", []) or []
        q  = res[0].get("indicators", {}).get("quote", [{}])[0]
        closes = q.get("close", []) if q else []
        divs = (res[0].get("events", {}) or {}).get("dividends", {}) or {}
        out = []
        for _, v in divs.items():
            amt = v.get("amount"); t = v.get("date") or v.get("ts") or v.get("timestamp")
            if amt is not None and t is not None: out.append((int(t), float(amt)))
        out.sort(key=lambda x: x[0])
        return ts, closes, out
    except Exception:
        return [], [], []

def yahoo_chart_last_close(session, symbol):
    url = f"https://query1.finance.yahoo.com/v8/finance/chart/{symbol}"
    try:
        j = session.get(url, headers=HEADERS, params={"range":"5d","interval":"1d"}, timeout=20).json()
        res = j.get("chart", {}).get("result", [])
        if not res: return None, None
        closes = res[0].get("indicators", {}).get("quote", [{}])[0].get("close", [])
        ts     = res[0].get("timestamp", [])
        pairs = [(c,t) for c,t in zip(closes, ts) if c is not None]
        if pairs:
            c, t = pairs[-1]
            return float(c), int(t) if t is not None else None
    except Exception:
        pass
    return None, None

def fill_missing_prices_with_chart(session, symbols, price_map, source_map, asof_map):
    for s in symbols:
        if price_map.get(s) is None:
            px, ts = yahoo_chart_last_close(session, s)
            if px is not None:
                price_map[s]=px; source_map[s]="chart_close"; asof_map[s]=ts
            _sleep()

# Options IV
def clamp_iv(iv: Optional[float]) -> Optional[float]:
    if iv is None or not math.isfinite(iv): return iv
    lo, hi = 0.05, 2.00
    return max(lo, min(hi, iv))

def per_period_yield_from_iv(iv: Optional[float], group: str) -> Optional[float]:
    if iv is None or not math.isfinite(iv): return None
    return (iv/52.0) if group=="Weekly" else (iv/13.0)

def yahoo_options_summary(session, symbol: str) -> Optional[dict]:
    url = f"https://query2.finance.yahoo.com/v7/finance/options/{symbol}"
    try:
        return session.get(url, headers=HEADERS, timeout=20).json().get("optionChain", {}).get("result", [None])[0]
    except Exception:
        return None

def yahoo_options_at_date(session, symbol: str, epoch: int) -> Optional[dict]:
    url = f"https://query2.finance.yahoo.com/v7/finance/options/{symbol}"
    try:
        j = session.get(url, headers=HEADERS, params={"date": epoch}, timeout=20).json()
        res = j.get("optionChain", {}).get("result", [])
        if not res: return None
        opts = res[0].get("options", [])
        return opts[0] if opts else None
    except Exception:
        return None

def _dte_days_epoch(epoch: int) -> int:
    return (datetime.fromtimestamp(epoch, tz=timezone.utc).date() - date.today()).days

def nearest_epochs_bracketing_30(expirations: List[int]):
    if not expirations: return None, None
    fut = [(ep, _dte_days_epoch(ep)) for ep in expirations if _dte_days_epoch(ep) >= 0]
    if not fut: return None, None
    below = sorted([x for x in fut if x[1] <= 30], key=lambda t: abs(t[1]-30))
    above = sorted([x for x in fut if x[1] >= 30], key=lambda t: abs(t[1]-30))
    return (below[0][0] if below else None), (above[0][0] if above else None)

def atm_iv_from_chain(chain: dict, ref_px: float, n_strikes=3) -> Optional[float]:
    if not chain: return None
    ivs=[]
    for side in ("calls","puts"):
        rows = chain.get(side, []) or []
        sample=[]
        for row in rows:
            strike=row.get("strike"); iv=row.get("impliedVolatility")
            if strike is None or iv is None: continue
            sample.append((abs(float(strike)-ref_px), float(iv)))
        sample.sort(key=lambda t:t[0])
        for _,iv in sample[:n_strikes]:
            if math.isfinite(iv) and iv>0: ivs.append(iv)
    return float(np.median(ivs)) if ivs else None

def robust_iv30_from_underlying(session, etf: str, underlying: Optional[str]) -> Tuple[Optional[float], str]:
    cands=[]
    if underlying: cands.append(("underlying", normalize_ticker(underlying)))
    cands.append(("etf", normalize_ticker(etf)))
    for label, sym in cands:
        base = yahoo_options_summary(session, sym)
        if not base: continue
        quote = base.get("quote", {}) or {}
        ref_px = quote.get("regularMarketPrice")
        if ref_px is None:
            pm,_,_ = yahoo_quote_batch_prices(session, [sym]); ref_px = pm.get(sym)
            if ref_px is None:
                ts,closes = yahoo_chart_hist(session, sym, "5d", "1d")
                if ts:
                    last = [(t,c) for t,c in zip(ts,closes) if c is not None]
                    ref_px = float(last[-1][1]) if last else None
        expiries = base.get("expirationDates", []) or []
        ep_lo, ep_hi = nearest_epochs_bracketing_30(expiries)
        iv_lo=iv_hi=None
        if ep_lo:
            ch = yahoo_options_at_date(session, sym, ep_lo); iv_lo = atm_iv_from_chain(ch, float(ref_px)) if ch else None; _sleep()
        if ep_hi and ep_hi!=ep_lo:
            ch = yahoo_options_at_date(session, sym, ep_hi); iv_hi = atm_iv_from_chain(ch, float(ref_px)) if ch else None
        iv=None
        if iv_lo and iv_hi:
            d_lo=_dte_days_epoch(ep_lo); d_hi=_dte_days_epoch(ep_hi)
            if d_lo is not None and d_hi is not None and d_hi!=d_lo:
                w=(30-d_lo)/(d_hi-d_lo); iv=iv_lo + w*(iv_hi-iv_lo)
        if iv is None: iv=iv_lo or iv_hi
        if iv and iv>0: return clamp_iv(iv), f"{label}:{sym}"
    # RV proxy
    for label, sym in cands:
        ts, closes = yahoo_chart_hist(session, sym, "3mo", "1d")
        data = [(t,c) for t,c in zip(ts,closes) if c is not None]
        if len(data) < 22: continue
        s = pd.Series([c for _,c in data], dtype="float64")
        rv = float(np.log(s/s.shift(1)).dropna().tail(30).std(ddof=0) * np.sqrt(252))
        if rv and rv>0: return clamp_iv(rv*1.10), f"rv_proxy:{label}:{sym}"
    return None, "unavailable"

# ---------------- Cadence engine ----------------
def next_ex_date_for_group(group: str, today: date) -> date:
    """Return the next ex-date on/after 'today' for a group from ANCHOR_EX cadence."""
    if group not in ANCHOR_EX:
        raise ValueError(f"Unknown group: {group}")
    anchor = ANCHOR_EX[group]
    step = 7 if group=="Weekly" else 28
    if today <= anchor:
        return anchor
    delta = (today - anchor).days
    k = (delta + step - 1)//step
    return anchor + timedelta(days=k*step)

def next_pay_date_from_ex(ex: date) -> date:
    """Pay = next business day (Mon-Fri) after ex; weekends rolled to Monday."""
    d = ex + timedelta(days=1)
    # 0=Mon .. 6=Sun
    if d.weekday() == 5:  # Saturday -> Monday
        return d + timedelta(days=2)
    if d.weekday() == 6:  # Sunday -> Monday
        return d + timedelta(days=1)
    return d

# ---------------- Modeling ----------------
class Event:
    __slots__=("ts","amt","pre_close","y")
    def __init__(self, ts:int, amt:float, pre_close:float):
        self.ts=ts; self.amt=amt; self.pre_close=pre_close; self.y=amt/pre_close

def _val_on_or_before(target_ts:int, ts_list: List[int], vals: List[Optional[float]])->Optional[float]:
    cand=[(t,v) for t,v in zip(ts_list,vals) if v is not None and t<=target_ts]
    if not cand: return None
    return float(cand[-1][1])

def _close_on_or_before(target_ts:int, ts_list: List[int], closes: List[Optional[float]])->Optional[float]:
    return _val_on_or_before(target_ts, ts_list, closes)

def build_events(ts: List[int], closes: List[Optional[float]], divs: List[Tuple[int,float]])->List[Event]:
    out=[]
    for t, amt in divs:
        pre=_close_on_or_before(t-2*60*60, ts, closes)
        if pre and pre>0 and amt and amt>0:
            out.append(Event(int(t), float(amt), float(pre)))
    out.sort(key=lambda e:e.ts)
    return out

def realized_vol_30d_asof(ts_list: List[int], closes: List[Optional[float]], asof_ts:int)->Optional[float]:
    data=[c for t,c in zip(ts_list, closes) if c is not None and t<=asof_ts]
    if len(data) < 25: return None
    s = pd.Series(data, dtype="float64")
    rv = float(np.log(s/s.shift(1)).dropna().tail(30).std(ddof=0) * np.sqrt(252))
    return rv if math.isfinite(rv) else None

def robust_filter_yields(ys: List[float], z_mad: float=3.0)->List[float]:
    if not ys: return ys
    med = float(np.median(ys))
    mad = float(np.median([abs(y-med) for y in ys])) or 1e-9
    keep=[]
    for y in ys:
        z = 0.6745 * (y - med) / mad
        if abs(z) <= z_mad:
            keep.append(y)
    return keep if keep else ys

def predict_hist_mom(prev_events: List[Event], ts: List[int], closes: List[Optional[float]],
                     ex_ts:int, K:int, w:float, L:int, beta:float, clamp:float,
                     rv_scale: float=1.0)->Optional[float]:
    if not prev_events: return None
    used = prev_events[-K:] if len(prev_events)>=K else prev_events[:]
    ys = robust_filter_yields([e.y for e in used], z_mad=3.0)
    y_last = ys[-1]; med = float(np.median(ys))
    y_hist = w*y_last + (1.0-w)*med
    now_price = _close_on_or_before(ex_ts, ts, closes)
    if now_price is None: return y_hist
    back_ts = ex_ts - L*24*60*60
    past_price = _close_on_or_before(back_ts, ts, closes)
    if past_price is None or past_price<=0: return y_hist
    m = max(-clamp, min(clamp, now_price/past_price - 1.0))
    beta_eff = beta * rv_scale
    return y_hist * (1.0 + beta_eff*m)

def is_weekly(fund:str)->bool: return GROUP_OF.get(fund,"")=="Weekly"
def min_train_events_needed(fund:str)->int:
    return MIN_TRAIN_EVENTS_WEEKLY if is_weekly(fund) else MIN_TRAIN_EVENTS_MONTHLY
def param_grid_for(fund:str)->Dict[str, List]:
    return GRID_WEEKLY if is_weekly(fund) else GRID_MONTHLY

# ---------------- Calibration store ----------------
CAL_DTYPES = {"key":"string","factor":"float64","err_ewma":"float64","samples":"int64","last_ex":"string","updated_at":"string"}

def load_calibration(path: Optional[str]) -> pd.DataFrame:
    df = pd.DataFrame({c: pd.Series(dtype=t) for c,t in CAL_DTYPES.items()})
    if not path: return df
    try:
        raw = pd.read_csv(path)
        for c,t in CAL_DTYPES.items():
            if c not in raw.columns: raw[c]=pd.Series(dtype=t)
        return raw.astype(CAL_DTYPES)
    except Exception:
        return df

def save_calibration(path: str, df: pd.DataFrame):
    if path:
        df.astype(CAL_DTYPES).to_csv(path, index=False)
        logging.info(f"Saved calibration → {path}")

def _cal_key_fund(fund:str)->str: return f"FUND:{normalize_ticker(fund)}"
def _get_cal_row(df:pd.DataFrame, key:str)->Optional[pd.Series]:
    if df.empty: return None
    m=df["key"]==key
    return df[m].iloc[0] if m.any() else None

def effective_cal_factor(df_cal:pd.DataFrame, fund:str, weekly: bool)->Tuple[float,float,int]:
    key=_cal_key_fund(fund)
    row=_get_cal_row(df_cal,key)
    if row is not None and pd.notna(row.get("factor")):
        return float(row["factor"]), float(row.get("err_ewma", CAL_DEFAULT_ERR_EWMA)), int(row.get("samples",0))
    # default
    return 1.0, CAL_DEFAULT_ERR_EWMA, 0

def update_calibration(df_cal: pd.DataFrame, fund: str, last_ex_date: Optional[date],
                       actual_last: Optional[float], predicted_last: Optional[float],
                       weekly: bool) -> pd.DataFrame:
    if last_ex_date is None or actual_last is None or predicted_last is None or predicted_last <= 0:
        return df_cal
    ratio = actual_last / predicted_last
    if not math.isfinite(ratio) or ratio <= 0: return df_cal
    alpha = CAL_ALPHA_WEEKLY if weekly else CAL_ALPHA_MONTHLY
    key = _cal_key_fund(fund)
    now_iso = date.today().isoformat()
    # upsert
    if df_cal.empty or not (df_cal["key"]==key).any():
        row = {
            "key": key, "factor": float(np.clip(ratio, *CAL_FACTOR_CLAMP)),
            "err_ewma": abs(ratio - 1.0), "samples": 1,
            "last_ex": last_ex_date.isoformat(), "updated_at": now_iso
        }
        df_cal = pd.concat([df_cal, pd.DataFrame([row])], ignore_index=True)
        return df_cal
    idx = df_cal.index[df_cal["key"] == key][0]
    old_f = float(df_cal.at[idx,"factor"]) if pd.notna(df_cal.at[idx,"factor"]) else 1.0
    logf = (1-alpha)*math.log(max(1e-9, old_f)) + alpha*math.log(ratio)
    new_f = float(np.clip(math.exp(logf), *CAL_FACTOR_CLAMP))
    old_e = float(df_cal.at[idx,"err_ewma"]) if pd.notna(df_cal.at[idx,"err_ewma"]) else CAL_DEFAULT_ERR_EWMA
    new_e = (1-alpha)*old_e + alpha*abs(ratio-1.0)
    df_cal.at[idx,"factor"]=new_f
    df_cal.at[idx,"err_ewma"]=new_e
    df_cal.at[idx,"samples"]=int(df_cal.at[idx,"samples"])+1
    df_cal.at[idx,"last_ex"]=last_ex_date.isoformat()
    df_cal.at[idx,"updated_at"]=now_iso
    return df_cal

# ---------------- Optimizer cache (in-memory only, persisted optionally) ----------------
OPT_CACHE_DTYPES = {
    "fund": "string", "K": "int64", "w": "float64", "L": "int64", "beta": "float64",
    "clamp": "float64", "train_medAPE": "float64", "n_train": "int64",
    "asof_utc": "int64", "last_event_ts": "int64"
}
def init_opt_cache(path: Optional[str]) -> pd.DataFrame:
    if not path:
        return pd.DataFrame({col: pd.Series(dtype=dt) for col, dt in OPT_CACHE_DTYPES.items()})
    try:
        df = pd.read_csv(path).astype(OPT_CACHE_DTYPES)
        return df
    except Exception:
        return pd.DataFrame({col: pd.Series(dtype=dt) for col, dt in OPT_CACHE_DTYPES.items()})

def cache_append(opt_cache: pd.DataFrame, row: dict) -> pd.DataFrame:
    for col in OPT_CACHE_DTYPES.keys():
        if col not in opt_cache.columns:
            opt_cache[col] = pd.Series(dtype=OPT_CACHE_DTYPES[col])
    for col in OPT_CACHE_DTYPES.keys():
        if col not in row: row[col] = None
    opt_cache.loc[len(opt_cache)] = row
    return opt_cache

def should_retrain(params_row: Optional[pd.Series], events: List[Event], ttl_days:int) -> bool:
    if params_row is None: return True
    now_ts = int(time.time())
    asof_utc = int(params_row.get("asof_utc") or 0)
    if now_ts - asof_utc > ttl_days*24*60*60: return True
    last_ev_ts_cache = int(params_row.get("last_event_ts") or 0)
    last_ev_ts_live  = events[-1].ts if events else 0
    return last_ev_ts_live > last_ev_ts_cache

def optimize_hist_mom_params(session, fund:str, ts, closes, events: List[Event]) -> Tuple[Optional[dict], Optional[List[float]], Optional[List[int]]]:
    need = min_train_events_needed(fund)
    if len(events) < need + 1:  # need at least one more to validate
        return None, None, None
    now_ts = int(time.time())
    start_cut = now_ts - TRAIN_WINDOW_DAYS*24*60*60
    idx = [i for i,e in enumerate(events) if start_cut <= e.ts < now_ts]
    if len(idx) < need:
        start_cut = now_ts - 365*24*60*60
        idx = [i for i,e in enumerate(events) if start_cut <= e.ts < now_ts]
        if len(idx) < need:
            return None, None, None
    grid = GRID_WEEKLY if is_weekly(fund) else GRID_MONTHLY
    best=None; best_params=None; apes_best=None
    for K in grid["K"]:
        for w in grid["w"]:
            for L in grid["L"]:
                for beta in grid["beta"]:
                    for clamp in grid["clamp"]:
                        apes=[]
                        for j in idx:
                            prior = [k for k in idx if k < j]
                            if not prior: continue
                            rv = realized_vol_30d_asof(ts, closes, events[j].ts) or RV_REF
                            rv_scale = float(np.clip(RV_REF / max(rv, 1e-6), RV_MIN_SCALE, RV_MAX_SCALE))
                            y_hat = predict_hist_mom([events[k] for k in prior], ts, closes, events[j].ts, K,w,L,beta,clamp, rv_scale)
                            if y_hat is None: continue
                            d_hat = y_hat * events[j].pre_close
                            d_act = events[j].amt
                            if d_act: apes.append(abs(d_hat-d_act)/d_act)
                        if not apes: continue
                        score = float(np.median(apes))
                        if best is None or score < best:
                            best=score; best_params={"K":K,"w":w,"L":L,"beta":beta,"clamp":clamp}; apes_best=apes
    return best_params, apes_best, idx

def total_return_12m_adj(session, symbol: str) -> Optional[float]:
    ts, adj = yahoo_chart_hist_adj(session, symbol, rng="1y", interval="1d")
    vals = [a for a in adj if a is not None]
    if not vals or len(vals) < 5:  return None
    start=None
    for a in adj:
        if a is not None: start=float(a); break
    end=None
    for a in reversed(adj):
        if a is not None: end=float(a); break
    if start is None or end is None or start <= 0: return None
    return end / start - 1.0

# ---------------- Historical range (NEW) ----------------
def hist_window_size(group: str) -> int:
    """Number of payouts to include: 13 for monthly groups, 52 for Weekly."""
    return 52 if group == "Weekly" else 13

def historical_dividend_range(events: List[Event], group: str, asof_ts: int) -> Tuple[Optional[float], Optional[float], int, str]:
    """
    Compute the historical dividend range used for the grey bar:
    - A/B/C/D: last 13 payouts on/before asof_ts
    - Weekly : last 52 payouts on/before asof_ts
    Returns (low, high, n_used, label["13m"|"52w"])
    """
    n = hist_window_size(group)
    used = [e.amt for e in events if e.ts <= asof_ts]
    if not used:
        return None, None, 0, ("52w" if group=="Weekly" else "13m")
    tail = used[-n:]
    if not tail:
        return None, None, 0, ("52w" if group=="Weekly" else "13m")
    return float(np.min(tail)), float(np.max(tail)), len(tail), ("52w" if group=="Weekly" else "13m")

# ---------------- Main ----------------
def run(save_path: Optional[str], audit: bool, range_pct: float,
        cal_factors_path: Optional[str], cal_save_path: Optional[str],
        opt_load_path: Optional[str], opt_save_path: Optional[str]) -> pd.DataFrame:

    logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s")
    logging.info("Fetching quotes for symbols…")

    session = requests_cache.CachedSession("ytp_cache", backend="sqlite", expire_after=CACHE_EXPIRE_SEC)
    session.headers.update(HEADERS)

    # Build roster from whitelist
    mapping = {sym: {"group": GROUP_OF[sym]} for sym in sorted(WHITELIST)}

    # Determine next Ex/Pay per group
    today = date.today()
    ex_by_group = {g: next_ex_date_for_group(g, today) for g in ["A","B","C","D","Weekly"]}
    pay_by_group = {g: next_pay_date_from_ex(ex_by_group[g]) for g in ex_by_group}

    # Prices
    tickers = sorted(mapping.keys())
    price_map, price_src, asof_map = yahoo_quote_batch_prices(session, tickers)
    fill_missing_prices_with_chart(session, tickers, price_map, price_src, asof_map)

    # Calibration store and optimizer cache
    cal_df = load_calibration(cal_factors_path)
    opt_cache = init_opt_cache(opt_load_path)

    records=[]
    for fund in tickers:
        grp = mapping[fund]["group"]
        ex_date  = ex_by_group[grp]
        pay_date = pay_by_group[grp]
        d2ex = (ex_date - today).days

        px = price_map.get(fund)
        px_asof = fmt_asof(asof_map.get(fund))

        # IV(30d)
        iv, iv_src = robust_iv30_from_underlying(session, fund, UNDERLYING.get(fund))
        iv = clamp_iv(iv); _sleep()

        # History (prices + dividends)
        ts, closes, divs = yahoo_chart_with_divs(session, fund, "18mo", "1d")
        events = build_events(ts, closes, divs)

        # Choose/reuse optimizer params
        params_row = opt_cache[opt_cache["fund"]==fund].iloc[0] if (not opt_cache.empty and (opt_cache["fund"]==fund).any()) else None
        best_params=None; train_medAPE=np.nan; n_train=0
        retrain = True
        if params_row is not None:
            retrain = should_retrain(params_row, events, OPT_TTL_DAYS)
            if not retrain:
                best_params = {"K": int(params_row["K"]), "w": float(params_row["w"]), "L": int(params_row["L"]),
                               "beta": float(params_row["beta"]), "clamp": float(params_row["clamp"])}
                train_medAPE = float(params_row["train_medAPE"]); n_train = int(params_row["n_train"])

        if retrain:
            bp, apes, train_idx = optimize_hist_mom_params(session, fund, ts, closes, events)
            if bp:
                best_params = bp
                if apes:
                    train_medAPE=float(np.median(apes)); n_train=len(apes)
                last_event_ts = events[train_idx[-1]].ts if train_idx else (events[-1].ts if events else 0)
                opt_cache = cache_append(opt_cache, {
                    "fund":fund, "K":bp["K"], "w":bp["w"], "L":bp["L"], "beta":bp["beta"], "clamp":bp["clamp"],
                    "train_medAPE": train_medAPE, "n_train": n_train,
                    "asof_utc": int(time.time()), "last_event_ts": int(last_event_ts)
                })
            else:
                best_params={"K":8,"w":0.8,"L":20,"beta":0.7,"clamp":0.12} if grp=="Weekly" else {"K":4,"w":0.8,"L":30,"beta":0.8,"clamp":0.15}

        # Prediction at ex-date; vol-aware beta
        ex_ts = int(datetime(ex_date.year, ex_date.month, ex_date.day, 14, 30, tzinfo=timezone.utc).timestamp())
        prev_events = [e for e in events if e.ts < ex_ts]
        rv_now = realized_vol_30d_asof(ts, closes, ex_ts) or RV_REF
        rv_scale = float(np.clip(RV_REF / max(rv_now, 1e-6), RV_MIN_SCALE, RV_MAX_SCALE))
        y_hat = predict_hist_mom(prev_events, ts, closes, ex_ts, best_params["K"], best_params["w"],
                                 best_params["L"], best_params["beta"], best_params["clamp"], rv_scale)

        # Fallback to IV per-period yield if needed
        if y_hat is None:
            y_iv = per_period_yield_from_iv(iv, grp)
            y_hat = y_iv

        # Convert to $ (point estimate)
        ytp_point = (y_hat * px) if (y_hat is not None and px is not None) else None

        # Calibration back-cast on last event (if possible)
        if events and len(events) >= 2:
            last_ev = events[-1]
            prior = [e for e in events if e.ts < last_ev.ts]
            rv_last = realized_vol_30d_asof(ts, closes, last_ev.ts) or RV_REF
            rv_scale_last = float(np.clip(RV_REF / max(rv_last, 1e-6), RV_MIN_SCALE, RV_MAX_SCALE))
            y_hat_last = predict_hist_mom(prior, ts, closes, last_ev.ts,
                                          best_params["K"], best_params["w"], best_params["L"],
                                          best_params["beta"], best_params["clamp"], rv_scale_last)
            pred_last = (y_hat_last * last_ev.pre_close) if y_hat_last is not None else None
            cal_df = update_calibration(cal_df, fund, datetime.fromtimestamp(last_ev.ts, tz=timezone.utc).date(),
                                        last_ev.amt, pred_last, weekly=(grp=="Weekly"))

        # Apply calibration
        cal_factor, err_ewma, samples = effective_cal_factor(cal_df, fund, weekly=(grp=="Weekly"))
        if ytp_point is not None:
            ytp_point *= cal_factor

        # ── Floors (client rule) ────────────────────────────────────────────
        min_floor = 0.0
        if px is not None and px > 0:
            min_floor = 0.0 if grp=="Weekly" else (MIN_ANN_YIELD_NON_WEEKLY / FREQ_BY_GROUP[grp]) * px
            if ytp_point is None:
                ytp_point = min_floor
            else:
                ytp_point = max(ytp_point, min_floor)

        # Range: fixed ±range_pct around midpoint, then clamp low to floor; ensure high>=low
        est_low = est_high = None
        if ytp_point is not None and px is not None and px > 0:
            half = abs(range_pct)
            est_low  = ytp_point * (1.0 - half)
            est_high = ytp_point * (1.0 + half)
            floor_val = 0.0 if grp=="Weekly" else min_floor
            if est_low < floor_val: est_low = floor_val
            if est_high < est_low: est_high = est_low
            ytp_range_str = f"${est_low:.2f}-${est_high:.2f}"
            fwd_yield_ann = f"{((ytp_point/px)*FREQ_BY_GROUP[grp])*100:.1f}%"
            ytp_point_str = f"${ytp_point:.2f}"
        else:
            ytp_point_str=""; ytp_range_str="$nan-$nan"; fwd_yield_ann=""

        # 12m total return (fund & underlying)
        tr12_fund = total_return_12m_adj(session, fund)
        und = UNDERLYING.get(fund)
        tr12_under = total_return_12m_adj(session, und) if und else None

        # ── Historical range for the grey bar (NEW) ────────────────────────
        hist_low, hist_high, hist_n, hist_label = historical_dividend_range(events, grp, ex_ts)
        hist_range_str = f"${hist_low:.2f}-${hist_high:.2f}" if (hist_low is not None and hist_high is not None) else ""

        # Record
        records.append({
            # identifiers
            "fund": fund, "Group": grp, "Underlying": und or "",
            # dates
            "Ex-Date": ex_date.isoformat(), "Pay Date": pay_date.isoformat(),
            # pricing / vols
            "Price": (f"{px:.2f}" if (px is not None and math.isfinite(px)) else ""),
            "Price ($)": (float(px) if (px is not None and math.isfinite(px)) else np.nan),
            "Price as of": px_asof,
            "IV (30d)": (f"{iv:.2f}" if iv is not None and math.isfinite(iv) else ""),
            "IV30": (float(iv) if (iv is not None and math.isfinite(iv)) else np.nan),

            # estimate (formatted + numeric)
            "Est. Dividend": ytp_point_str,
            "Est. Dividend ($)": (float(ytp_point) if (ytp_point is not None and math.isfinite(ytp_point)) else np.nan),
            "Est. Range": ytp_range_str,
            "EstLow": (float(est_low) if (est_low is not None and math.isfinite(est_low)) else np.nan),
            "EstHigh": (float(est_high) if (est_high is not None and math.isfinite(est_high)) else np.nan),
            "Fwd Yield (Ann.)": fwd_yield_ann,

            # historical range (NEW)
            "Hist Range (13m/52w)": hist_range_str,
            "HistLow": (float(hist_low) if (hist_low is not None and math.isfinite(hist_low)) else np.nan),
            "HistHigh": (float(hist_high) if (hist_high is not None and math.isfinite(hist_high)) else np.nan),
            "HistN": int(hist_n),
            "HistLabel": hist_label,

            # misc
            "Days to Ex": d2ex if d2ex is not None else "",
            "TR 12m (Fund, DR)": (f"{tr12_fund*100:.1f}%" if tr12_fund is not None else ""),
            "TR 12m (Underlying, DR)": (f"{tr12_under*100:.1f}%" if tr12_under is not None else ""),

            # audit
            **({"iv_source": iv_src, "ytp_cal_factor": f"{cal_factor:.3f}", "ytp_cal_samples": samples,
                "ytp_err_ewma": f"{float(err_ewma)*100:.1f}%", "opt_K": best_params["K"], "opt_w": f"{best_params['w']:.2f}",
                "opt_L": best_params["L"], "opt_beta": f"{best_params['beta']:.2f}", "opt_clamp": f"{best_params['clamp']:.2f}",
                "train_medAPE": (f"{train_medAPE:.3f}" if train_medAPE==train_medAPE else "")} if audit else {})
        })

    # Persist caches
    from pandas.api.types import is_integer_dtype
    if opt_save_path and not opt_cache.empty:
        opt_cache.astype({k:v for k,v in opt_cache.dtypes.items()}).to_csv(opt_save_path, index=False)
        logging.info(f"Saved optimizer cache → {opt_save_path}")
    if cal_save_path:
        save_calibration(cal_save_path, cal_df)

    # Column order
    cols = [
        "fund","Group","Underlying","Ex-Date","Pay Date",
        "Price","Price ($)","Price as of","IV (30d)","IV30",
        "Est. Dividend","Est. Dividend ($)","Est. Range","EstLow","EstHigh","Fwd Yield (Ann.)",
        "Hist Range (13m/52w)","HistLow","HistHigh","HistN","HistLabel",
        "Days to Ex","TR 12m (Fund, DR)","TR 12m (Underlying, DR)"
    ]
    if audit:
        cols += ["iv_source","ytp_cal_factor","ytp_cal_samples","ytp_err_ewma","opt_K","opt_w","opt_L","opt_beta","opt_clamp","train_medAPE"]

    df = pd.DataFrame.from_records(records, columns=cols)

    # Sort by soonest ex-date (ascending)
    def _to_dt(x):
        try: return pd.to_datetime(x).date()
        except Exception: return pd.NaT
    df["_ex_sort"] = df["Ex-Date"].apply(_to_dt)
    df = df.sort_values("_ex_sort", na_position="last", kind="mergesort").drop(columns=["_ex_sort"]).reset_index(drop=True)

    if save_path:
        if save_path.lower().endswith(".xlsx"):
            df.to_excel(save_path, index=False)
        else:
            df.to_csv(save_path, index=False)
        logging.info(f"Saved output → {save_path}")

    return df

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--save", type=str, default="ytp_output.xlsx", help="CSV or XLSX output path")
    ap.add_argument("--audit", action="store_true", help="Include optimizer/calibration internals")
    ap.add_argument("--range-pct", type=float, default=RANGE_PCT_DEFAULT, help="Fixed ±pct range width around midpoint (default 0.10)")
    ap.add_argument("--cal-factors", type=str, default=CAL_PATH_DEFAULT, help="Load calibration factors CSV")
    ap.add_argument("--cal-save", type=str, default="ytp_calibration.csv", help="Save calibration factors CSV")
    ap.add_argument("--opt-load", type=str, default="ytp_opt_cache.csv", help="Load optimizer params CSV")
    ap.add_argument("--opt-save", type=str, default="ytp_opt_cache.csv", help="Save optimizer params CSV")
    args = ap.parse_args()

    df = run(save_path=args.save, audit=args.audit, range_pct=args.range_pct,
             cal_factors_path=args.cal_factors, cal_save_path=args.cal_save,
             opt_load_path=args.opt_load, opt_save_path=args.opt_save)

    with pd.option_context("display.max_rows", 500, "display.max_columns", None):
        print(df.to_string(index=False))

if __name__ == "__main__":
    main()
