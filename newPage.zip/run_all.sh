#!/usr/bin/env bash
set -e
pip install -r requirements.py --break-system-packages
pip install openpyxl --break-system-packages
python ytp_pipeline.py --save ytp_output.xlsx
python render_upcoming_distributions.py --input ytp_output.xlsx --output upcoming_distributions.png
