# YieldTrack Pro — Upcoming Distributions (with Historical Range)

This bundle includes:
- **ytp_pipeline.py** — generates the dataset with *historical dividend ranges*:
  - `HistLow`/`HistHigh` = grey bar (last **13 payouts** for A/B/C/D, **52 payouts** for Weekly)
  - `Est. Dividend ($)`  = blue dot (this run’s estimate)
  - Also keeps the existing columns you already use
- **render_upcoming_distributions.py** — draws the exact panel:
  - Grey bar = `HistLow`→`HistHigh`
  - Blue dot = `Est. Dividend ($)`
  - Grouped by **A / B / C / D / Weekly**

## Quick Start

```bash
# 1) Install requirements (in a venv is recommended)
pip install -r requirements.txt

# 2) Run the pipeline (writes ytp_output.xlsx by default)
python ytp_pipeline.py --save ytp_output.xlsx

# 3) Render the visualization
python render_upcoming_distributions.py --input ytp_output.xlsx --output upcoming_distributions.png
```

### Notes
- The pipeline uses Yahoo endpoints with a small cache window (30 minutes) via `requests-cache`.
- If options chains are thin, IV(30d) falls back to a realized-vol proxy.
- Estimate range is fixed ±10% around the calibrated point. Floors applied per your rules.
